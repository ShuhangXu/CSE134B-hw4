export default [
    {
        "title": "The Reflective Practitioner",
        "date": "2017-07-01",
        "summary": "A leading M.I.T. social scientist and consultant examines five professions (engineering, architecture, management, psychotherapy, and town planning) to show how professionals really go about solving problems. "
    },
    {
        "title": "The Mythical Man Month",
        "date": "2021-07-01",
        "summary": "The Mythical Man-Month: Essays on Software Engineering is a book on software engineering and project management by Fred Brooks first published in 1975, with subsequent editions in 1982 and 1995."
    },
    {
        "title": "Chrome, Edge, Firefox, Opera, Safari",
        "date": "2022-10-12",
        "summary": "he Pragmatic Programmer: From Journeyman to Master is a book about computer programming and software engineering, written by Andrew Hunt and David Thomas and published in October 1999. The book does not present a systematic theory, but rather a collection of tips to improve the development process in a pragmatic way. The main qualities of what the authors refer to as a pragmatic programmer are being an early adopter, to have fast adaptation, inquisitiveness and critical thinking, realism"
    },
]